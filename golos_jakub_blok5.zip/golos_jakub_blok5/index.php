<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wodospady</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    
    <header>
        <h2>Łowcy wodospadów</h2>
    </header>
    <main>
        <div class="blokb">

            <!-- SKRYPT 1 -->
             
            <?php
                $bazadanych = mysqli_connect('localhost', 'root', '', 'wodospady');
                $zapytanie1 = "SELECT idKontynent, nazwa FROM kontynenty";
                $wynik = mysqli_query($bazadanych, $zapytanie1);
                while ($wiersz = mysqli_fetch_assoc($wynik)){
                    echo '<a href="index.php?id=' . $wiersz['idKontynent'] . '">'. $wiersz['nazwa'] . '</a>';
                }
                mysqli_close($bazadanych);
            ?>
        </div>
        <div class="bloks">
            <table>
                <tr>
                    <th>Identyfikator</th>
                    <th>Państwo</th>
                    <th>Nazwa wodospadu</th>
                    <th>Wysokość</th>
                </tr>

                <!-- SKRYPT 2 -->

                <?php
                    $id = isset($_GET['id']) ? $_GET['id'] : 6;
                    $bazadanych = mysqli_connect('localhost', 'root', '', 'wodospady');
                    $zapytanie3 = "SELECT idObiekt, panstwo, nazwa, wartoscCechy FROM obiekty WHERE idRodzaj LIKE '10' AND idKontynent LIKE '$id'";
                    $wynik = mysqli_query($bazadanych, $zapytanie3);
                    while ($wiersz = mysqli_fetch_assoc($wynik)){
                        echo '<tr>';
                        echo '<td>' . $wiersz['idObiekt'] . '</td>';
                        echo '<td>' . $wiersz['panstwo'] . '</td>';
                        echo '<td>' . $wiersz['nazwa'] . '</td>';
                        echo '<td>' . $wiersz['wartoscCechy'] . '</td>';
                        echo '</tr>';
                    }
                    mysqli_close($bazadanych);
                ?>
            </table>
            <p>Wpisz osiągniecie do bazy</p><br>
            <label for="input">Identyfikator wodospadu</label>
            <input type="text" id="input">
            <label for="select">turysta</label>
            <select name="select" id="select">

                <!-- SKRYPT 3 -->

                <?php
                    $bazadanych = mysqli_connect('localhost', 'root', '', 'wodospady');
                    $zapytanie5 = "SELECT idTurysta, nick FROM turysci";
                    $wynik = mysqli_query($bazadanych, $zapytanie5);
                    while ($wiersz = mysqli_fetch_assoc($wynik)){
                        echo '<option value="' . $wiersz['idTurysta'] . '">' . $wiersz['nick'] . '</option>';
                    }
                    mysqli_close($bazadanych);
                ?>
            </select>
            <button>Wpisz</button>
        </div>
    </main>
    <article>
        <h3>Wodospady w Polsce</h3>
        <img src="kamienczyk.jpg" alt="wodospad">
        <img src="siklawica.jpg" alt="wodospad">
        <img src="siklawa.jpg" alt="wodospad">
        <img src="wilczki.jpg" alt="wodospad">
    </article>
    <footer>
        <p>Autor: Jakub Gołoś</p>
    </footer>
</body>
</html>
